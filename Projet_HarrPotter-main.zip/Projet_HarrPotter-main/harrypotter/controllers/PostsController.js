const prisma = require("../config/prisma");


class PostsController {

    async index(req, res) {
        
        try {
          const posts = await prisma.post.findMany();
          return res.status(200).json(posts);
        }catch(e) {
          return res.status(500).json({message: e.message});
        }
    };

    async store(req, res) {
      try {
        const body = req.body;
        // const output = await vine.validate({
        //   schema: storeUserValidator,
        //   data
        // })
        const posts = await prisma.post.create({
          data: body,
        })
        
        return res.status(200).json(posts);
      }catch(e) {
        return res.status(500).json({message: e.message});
      };
    } 

    async show(req, res) {
      try {
        const id = req.params.id;
        const posts = await prisma.post.findUnique({
          where: {
            id: id,
          },
        })
        return res.status(200).json(posts);
      }catch(e) {
        return res.status(404).json({ message: "User not found" });
      };
    }

    async update(req, res) {
      try {
        const id = req.params.id;
        const body = req.body;
        const post = await prisma.post.find((post) => post.id === Number(id));
        post.name = body.name;
        return res.status(200).json(posts);

      }catch(e) {
          return res.status(404).json({ message: "User not found" });
      
       
      };
    }

    async delete(req, res) {
      if (post){
        try {
          const id = req.params.id;
          const posts = await prisma.post.find((post) => post.id === Number(id));
          posts = post.filter((post) => post.id !== Number(id));
        
          return res.status(200).json(posts);
        }catch(e) {
          return res.status(404).json({ message: "User not found" });
       };
      }
    }  
}

module.exports = new PostsController();